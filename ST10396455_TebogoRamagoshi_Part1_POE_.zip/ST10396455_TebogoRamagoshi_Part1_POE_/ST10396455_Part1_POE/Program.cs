﻿using ST10396455_Part1_POE;

internal class Program
{
    private static void Main(string[] args)
    {
            // Creating a new instance of Recipe
            Recipe recipe = new Recipe();

            // Entering and displaying the recipe
            recipe.EnterRecipe();
            recipe.DisplayRecipe();

            double factor;
            // Prompting user to enter scaling factor
            while (true)
            {
                Console.Write("\nEnter scaling factor (0.5, 2, or 3): ");
                string input = Console.ReadLine().Trim();

                // Validating user input for scaling factor
                if (!string.IsNullOrEmpty(input))
                {
                    if (input == "0.5" || input == "2" || input == "3")
                    {
                        factor = double.Parse(input);
                        break;
                    }
                }
                Console.WriteLine("Invalid input. Please enter 0.5, 2, or 3.");
            }

            // Scaling and displaying the recipe
            recipe.ScaleRecipe(factor);
            recipe.DisplayRecipe();

            // Resetting quantities (not implemented yet)
            recipe.ResetQuantities(); Console.WriteLine("Hello, World!");
    }
}