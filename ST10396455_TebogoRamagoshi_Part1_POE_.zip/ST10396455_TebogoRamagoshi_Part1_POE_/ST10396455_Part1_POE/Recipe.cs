﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10396455_Part1_POE
{
    internal class Recipe
    {
        // Properties to store recipe details
        public string[] Ingredients { get; set; }
        public double[] Quantities { get; set; }
        public string[] Units { get; set; }
        public string[] Steps { get; set; }

        // Method to enter recipe details
        public void EnterRecipe()
        {
            Console.Write("Enter the number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            // Initializing arrays to store ingredients, quantities, and units
            Ingredients = new string[numIngredients];
            Quantities = new double[numIngredients];
            Units = new string[numIngredients];

            // Prompting user to enter ingredient details
            Console.WriteLine("Enter ingredients:");
            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write("Ingredient {0} name: ", i + 1);
                Ingredients[i] = Console.ReadLine();

                Console.Write("Quantity of {0}: ", Ingredients[i]);
                Quantities[i] = double.Parse(Console.ReadLine());

                Console.Write("Unit of measurement for {0}: ", Ingredients[i]);
                Units[i] = Console.ReadLine();
            }

            // Prompting user to enter steps of the recipe
            Console.Write("Enter the number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            // Initializing array to store steps
            Steps = new string[numSteps];
            Console.WriteLine("Enter steps:");
            for (int i = 0; i < numSteps; i++)
            {
                Console.Write("Step {0}: ", i + 1);
                Steps[i] = Console.ReadLine();
            }
        }

        // Method to display the full recipe
        public void DisplayRecipe()
        {
            Console.WriteLine("\nRecipe:");
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < Ingredients.Length; i++)
            {
                Console.WriteLine("{0} {1} of {2}", Quantities[i], Units[i], Ingredients[i]);
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < Steps.Length; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, Steps[i]);
            }
        }

        // Method to scale the recipe by a given factor
        public void ScaleRecipe(double factor)
        {
            // Scaling the quantities of ingredients by the given factor
            for (int i = 0; i < Quantities.Length; i++)
            {
                Quantities[i] *= factor;
            }
        }

        // Method to reset ingredient quantities to original values
        public void ResetQuantities()
        {
            // TODO: Implement resetting to original quantities
        }

        // Method to clear all recipe data
        public void ClearData()
        {
            // Clearing all arrays storing recipe data
            Ingredients = null;
            Quantities = null;
            Units = null;
            Steps = null;
        }
    }
}
