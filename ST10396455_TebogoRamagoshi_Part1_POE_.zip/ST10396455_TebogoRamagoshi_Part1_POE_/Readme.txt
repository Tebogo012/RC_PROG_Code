1. unzip the document first before running the ST10396455_Part1_POE.sln

2. Example of code running in readme.docx